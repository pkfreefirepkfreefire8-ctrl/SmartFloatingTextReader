package com.smartreader.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.smartreader.app.utils.*
import java.util.LinkedList
import java.util.Queue

/**
 * Accessibility Service that detects all visible text on screen and supports
 * tap-to-read by intercepting user taps on text elements.
 */
class ScreenReaderAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenReaderAccessibilityService? = null
            private set

        // Callbacks for the overlay service
        var onTextElementsDetected: ((List<ScreenTextElement>) -> Unit)? = null
        var onUserTappedElement: ((ScreenTextElement) -> Unit)? = null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        android.util.Log.d("ScreenReaderA11y", "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val root = rootInActiveWindow ?: return

        try {
            when (event.eventType) {
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                    val elements = extractAllVisibleText(root)
                    onTextElementsDetected?.invoke(elements)
                }
                AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                    // Handle tap-to-read: detect which text element was tapped
                    handleTapEvent(event)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ScreenReaderA11y", "Error processing event", e)
        } finally {
            root.recycle()
        }
    }

    private fun handleTapEvent(event: AccessibilityEvent) {
        val source = event.source ?: return
        try {
            if (source.text != null && source.text.isNotBlank()) {
                val bounds = Rect()
                source.getBoundsInScreen(bounds)
                val element = ScreenTextElement(
                    text = TextUtils.normalizeText(source.text),
                    bounds = bounds,
                    nodeType = detectNodeType(source),
                    isClickable = source.isClickable,
                    isVisible = source.isVisibleToUser,
                    depth = 0,
                    nodeId = source.viewIdResourceName
                )
                if (TextUtils.isMeaningfulText(element.text)) {
                    onUserTappedElement?.invoke(element)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ScreenReaderA11y", "Error in tap handler", e)
        } finally {
            source.recycle()
        }
    }

    /**
     * Recursively extracts all visible text elements from the accessibility tree.
     * Reads top-to-bottom based on screen Y position.
     */
    fun extractAllVisibleText(root: AccessibilityNodeInfo?): List<ScreenTextElement> {
        val elements = mutableListOf<ScreenTextElement>()
        if (root == null) return elements

        val seenTexts = HashSet<String>()

        // BFS/DFS hybrid - collect all nodes with text
        collectTextNodes(root, elements, seenTexts, 0)

        // Sort by Y then X position
        elements.sort()

        return elements.toList()
    }

    private fun collectTextNodes(
        node: AccessibilityNodeInfo,
        elements: MutableList<ScreenTextElement>,
        seenTexts: HashSet<String>,
        depth: Int
    ) {
        if (depth > 30) return // Prevent deep recursion

        try {
            // Check if node is visible
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (!node.isVisibleToUser) return
            }

            // Skip decorative and non-visible elements
            if (node.className?.toString()?.contains("image", ignoreCase = true) == true) {
                // Only process content descriptions for images
                if (node.contentDescription == null || node.contentDescription.isBlank()) {
                    // Still process children of layouts even if they contain images
                    // But skip pure image nodes
                    val childCount = node.childCount
                    if (childCount == 0) return
                }
            }

            // Skip system UI elements
            val className = node.className?.toString() ?: ""
            if (isDecorativeElement(className, node)) {
                // Still process children
                val childCount = node.childCount
                for (i in 0 until childCount) {
                    val child = node.getChild(i) ?: continue
                    collectTextNodes(child, elements, seenTexts, depth + 1)
                    child.recycle()
                }
                return
            }

            // Process node text
            val text = TextUtils.normalizeText(
                node.text ?: node.contentDescription ?: node.hintText
            )

            if (TextUtils.isMeaningfulText(text) && !seenTexts.contains(text)) {
                // Remove duplicates with fuzzy matching
                val isDuplicate = seenTexts.any { existing ->
                    existing.length == text.length &&
                            (existing.contains(text) || text.contains(existing))
                }

                if (!isDuplicate) {
                    seenTexts.add(text)
                    val bounds = Rect()
                    node.getBoundsInScreen(bounds)

                    // Only add if bounds are valid and on screen
                    if (bounds.width() > 0 && bounds.height() > 0) {
                        elements.add(
                            ScreenTextElement(
                                text = text,
                                bounds = bounds,
                                nodeType = detectNodeType(node),
                                isClickable = node.isClickable,
                                isVisible = true,
                                depth = depth,
                                nodeId = node.viewIdResourceName
                            )
                        )
                    }
                }
            }

            // Process children
            val childCount = node.childCount
            for (i in 0 until childCount) {
                val child = node.getChild(i) ?: continue
                collectTextNodes(child, elements, seenTexts, depth + 1)
                child.recycle()
            }

        } catch (e: Exception) {
            android.util.Log.e("ScreenReaderA11y", "Error in collectTextNodes", e)
        }
    }

    private fun isDecorativeElement(className: String, node: AccessibilityNodeInfo): Boolean {
        val lower = className.lowercase()
        return when {
            lower.contains("decor") -> true
            lower.contains("divider") -> true
            lower.contains("separator") -> true
            lower.contains("line") && !node.isClickable -> true
            lower.contains("progressbar") -> true
            lower.contains("seekbar") -> true
            lower.contains("scrollbar") -> true
            lower.contains("surfaceview") -> true
            lower.contains("textureview") -> true
            lower.contains("glsurfaceview") -> true
            else -> false
        }
    }

    /**
     * Perform a tap gesture at the given coordinates.
     * Used internally for accessibility gesture dispatch.
     */
    fun performTap(x: Float, y: Float): Boolean {
        val path = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 1))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    override fun onInterrupt() {
        android.util.Log.d("ScreenReaderA11y", "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        android.util.Log.d("ScreenReaderA11y", "Accessibility service destroyed")
    }
}
