package com.smartreader.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.smartreader.app.R
import com.smartreader.app.service.FloatingOverlayService
import com.smartreader.app.utils.PreferenceManager

class MainActivity : AppCompatActivity() {

    private lateinit var preferenceManager: PreferenceManager
    private lateinit var statusText: TextView
    private lateinit var startServiceButton: Button
    private lateinit var accessibilityButton: Button
    private lateinit var overlayPermissionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preferenceManager = (application as com.smartreader.app.SmartReaderApplication).preferenceManager

        statusText = findViewById(R.id.status_text)
        startServiceButton = findViewById(R.id.btn_start_service)
        accessibilityButton = findViewById(R.id.btn_accessibility)
        overlayPermissionButton = findViewById(R.id.btn_overlay_permission)

        findViewById<Button>(R.id.btn_open_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        setupButtons()
        updateUI()
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun setupButtons() {
        startServiceButton.setOnClickListener {
            if (!hasOverlayPermission()) {
                showPermissionAlert("Overlay Permission", getString(R.string.overlay_permission_required))
                return@setOnClickListener
            }
            if (!isAccessibilityServiceEnabled()) {
                showPermissionAlert("Accessibility Service", getString(R.string.accessibility_permission_required))
                return@setOnClickListener
            }

            toggleService()
        }

        accessibilityButton.setOnClickListener {
            openAccessibilitySettings()
        }

        overlayPermissionButton.setOnClickListener {
            openOverlayPermissionSettings()
        }
    }

    private fun toggleService() {
        val serviceIntent = Intent(this, FloatingOverlayService::class.java)
        if (preferenceManager.isServiceRunning) {
            stopService(serviceIntent)
            preferenceManager.isServiceRunning = false
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            preferenceManager.isServiceRunning = true
        }
        updateUI()
    }

    private fun updateUI() {
        val hasOverlay = hasOverlayPermission()
        val hasAccessibility = isAccessibilityServiceEnabled()
        val isRunning = preferenceManager.isServiceRunning

        when {
            !hasOverlay -> {
                statusText.text = "⚠️ Overlay permission required"
                startServiceButton.isEnabled = false
            }
            !hasAccessibility -> {
                statusText.text = "⚠️ Accessibility service not enabled"
                startServiceButton.isEnabled = false
            }
            isRunning -> {
                statusText.text = "● Service is running"
                startServiceButton.text = "Stop Service"
                startServiceButton.isEnabled = true
            }
            else -> {
                statusText.text = "Ready to start"
                startServiceButton.text = "Start Service"
                startServiceButton.isEnabled = true
            }
        }

        overlayPermissionButton.text = if (hasOverlay) "✓ Overlay Permission Granted" else "Grant Overlay Permission"
        overlayPermissionButton.setBackgroundColor(
            if (hasOverlay) 0xFF4CAF50.toInt() else 0xFFFF5722.toInt()
        )

        accessibilityButton.text = if (hasAccessibility) "✓ Accessibility Enabled" else "Enable Accessibility Service"
        accessibilityButton.setBackgroundColor(
            if (hasAccessibility) 0xFF4CAF50.toInt() else 0xFFFF5722.toInt()
        )
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val serviceName = "${packageName}/.service.ScreenReaderAccessibilityService"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(serviceName) || enabledServices.contains(
            "com.smartreader.app/.service.ScreenReaderAccessibilityService"
        )
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun openOverlayPermissionSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun showPermissionAlert(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Open Settings") { _, _ ->
                if (title.contains("Overlay")) {
                    openOverlayPermissionSettings()
                } else {
                    openAccessibilitySettings()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
