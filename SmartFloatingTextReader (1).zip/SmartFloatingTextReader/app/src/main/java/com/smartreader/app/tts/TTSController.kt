package com.smartreader.app.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.smartreader.app.utils.PreferenceManager
import com.smartreader.app.utils.ScreenTextElement
import java.util.Locale

/**
 * Manages Text-to-Speech functionality with support for multiple languages,
 * adjustable speed/pitch, and continuous reading with element tracking.
 */
class TTSController(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var currentElementIndex = -1
    private var textElements: List<ScreenTextElement> = emptyList()
    private var isPaused = false
    private var readingState = ReadingState.IDLE

    private lateinit var preferenceManager: PreferenceManager

    var onReadingProgress: ((elementIndex: Int, totalElements: Int) -> Unit)? = null
    var onReadingComplete: (() -> Unit)? = null
    var onElementStarted: ((ScreenTextElement) -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    enum class ReadingState {
        IDLE, READING, PAUSED
    }

    fun initialize(prefs: PreferenceManager) {
        preferenceManager = prefs

        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                applyPreferences()
            } else {
                onError?.invoke("TTS initialization failed with status: $status")
            }
        }

        // Get available voices for language support
        tts?.voices?.let { voices ->
            voices.forEach { voice ->
                android.util.Log.d("TTSController", "Available voice: ${voice.name}, locale: ${voice.locale}")
            }
        }

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                val index = utteranceId?.toIntOrNull() ?: return
                currentElementIndex = index
                readingState = ReadingState.READING
                if (index in textElements.indices) {
                    onElementStarted?.invoke(textElements[index])
                }
                onReadingProgress?.invoke(index, textElements.size)
            }

            override fun onDone(utteranceId: String?) {
                val index = utteranceId?.toIntOrNull() ?: return
                if (readingState == ReadingState.READING) {
                    readNextElement(index + 1)
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                val index = utteranceId?.toIntOrNull() ?: return
                // Skip problematic element and continue
                if (readingState == ReadingState.READING) {
                    readNextElement(index + 1)
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                val index = utteranceId?.toIntOrNull() ?: return
                if (readingState == ReadingState.READING) {
                    readNextElement(index + 1)
                }
            }
        })
    }

    fun applyPreferences() {
        tts?.let { ttsEngine ->
            ttsEngine.setSpeechRate(preferenceManager.speechRate)
            ttsEngine.setPitch(preferenceManager.pitch)

            // Set language based on preference
            val langCode = preferenceManager.language
            setLanguage(langCode)
        }
    }

    fun setLanguage(languageCode: String) {
        tts?.let { ttsEngine ->
            val locale = when (languageCode) {
                "en" -> Locale.US
                "en-GB" -> Locale.UK
                "en-AU" -> Locale("en", "AU")
                "en-IN" -> Locale("en", "IN")
                "es" -> Locale("es")
                "es-MX" -> Locale("es", "MX")
                "fr" -> Locale.FRANCE
                "fr-CA" -> Locale.CANADA_FRENCH
                "de" -> Locale.GERMANY
                "it" -> Locale.ITALY
                "pt" -> Locale("pt")
                "pt-BR" -> Locale("pt", "BR")
                "ru" -> Locale("ru")
                "ja" -> Locale.JAPAN
                "ko" -> Locale.KOREA
                "zh" -> Locale.CHINESE
                "zh-TW" -> Locale.TAIWAN
                "ar" -> Locale("ar")
                "hi" -> Locale("hi")
                "tr" -> Locale("tr")
                "nl" -> Locale("nl")
                "pl" -> Locale("pl")
                "sv" -> Locale("sv")
                "da" -> Locale("da")
                "fi" -> Locale("fi")
                "no" -> Locale("no")
                "cs" -> Locale("cs")
                "th" -> Locale("th")
                "vi" -> Locale("vi")
                "id" -> Locale("id")
                "ms" -> Locale("ms")
                "ro" -> Locale("ro")
                "uk" -> Locale("uk")
                "el" -> Locale("el")
                "he" -> Locale("he")
                else -> Locale.US
            }

            val result = ttsEngine.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to English
                ttsEngine.setLanguage(Locale.US)
            }
        }
    }

    fun getAvailableLanguages(): List<String> {
        return listOf(
            "en", "en-GB", "en-AU", "en-IN",
            "es", "es-MX", "fr", "fr-CA", "de", "it",
            "pt", "pt-BR", "ru", "ja", "ko",
            "zh", "zh-TW", "ar", "hi", "tr",
            "nl", "pl", "sv", "da", "fi", "no",
            "cs", "th", "vi", "id", "ms", "ro", "uk", "el", "he"
        )
    }

    fun getLanguageDisplayName(code: String): String {
        return when (code) {
            "en" -> "English (US)"
            "en-GB" -> "English (UK)"
            "en-AU" -> "English (AU)"
            "en-IN" -> "English (IN)"
            "es" -> "Español"
            "es-MX" -> "Español (MX)"
            "fr" -> "Français"
            "fr-CA" -> "Français (CA)"
            "de" -> "Deutsch"
            "it" -> "Italiano"
            "pt" -> "Português"
            "pt-BR" -> "Português (BR)"
            "ru" -> "Русский"
            "ja" -> "日本語"
            "ko" -> "한국어"
            "zh" -> "中文"
            "zh-TW" -> "中文 (TW)"
            "ar" -> "العربية"
            "hi" -> "हिन्दी"
            "tr" -> "Türkçe"
            "nl" -> "Nederlands"
            "pl" -> "Polski"
            "sv" -> "Svenska"
            "da" -> "Dansk"
            "fi" -> "Suomi"
            "no" -> "Norsk"
            "cs" -> "Čeština"
            "th" -> "ไทย"
            "vi" -> "Tiếng Việt"
            "id" -> "Bahasa Indonesia"
            "ms" -> "Bahasa Melayu"
            "ro" -> "Română"
            "uk" -> "Українська"
            "el" -> "Ελληνικά"
            "he" -> "עברית"
            else -> code
        }
    }

    fun startReading(elements: List<ScreenTextElement>, startIndex: Int = 0) {
        if (!isInitialized) {
            onError?.invoke("TTS not initialized")
            return
        }
        stop()
        textElements = elements.filter { it.text.isNotBlank() }
        if (textElements.isEmpty()) {
            onError?.invoke("No text to read")
            return
        }
        readingState = ReadingState.READING
        isPaused = false
        readNextElement(startIndex.coerceIn(0, textElements.lastIndex))
    }

    private fun readNextElement(index: Int) {
        if (index >= textElements.size) {
            readingState = ReadingState.IDLE
            currentElementIndex = -1
            onReadingProgress?.invoke(textElements.size, textElements.size)
            onReadingComplete?.invoke()
            return
        }
        if (isPaused || readingState == ReadingState.IDLE) return

        val element = textElements[index]
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, index.toString())

        // Add pauses based on element type
        val textToSpeak = when (element.nodeType) {
            com.smartreader.app.utils.NodeType.HEADING -> {
                ". ${element.text}. "
            }
            com.smartreader.app.utils.NodeType.PARAGRAPH -> {
                "${element.text}. "
            }
            com.smartreader.app.utils.NodeType.BUTTON -> {
                "Button: ${element.text}. "
            }
            com.smartreader.app.utils.NodeType.LINK -> {
                "Link: ${element.text}. "
            }
            else -> element.text
        }

        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params, "utterance_$index")
    }

    fun pause() {
        isPaused = true
        readingState = ReadingState.PAUSED
        tts?.stop()
    }

    fun resume() {
        if (!isPaused) return
        isPaused = false
        val resumeIndex = currentElementIndex.coerceAtLeast(0)
        readNextElement(resumeIndex)
    }

    fun stop() {
        isPaused = false
        readingState = ReadingState.IDLE
        currentElementIndex = -1
        tts?.stop()
    }

    fun jumpToElement(elements: List<ScreenTextElement>, targetElement: ScreenTextElement) {
        if (!isInitialized) return

        // Find the matching element by comparing bounds and text
        val matchedIndex = elements.indexOfFirst {
            it.bounds == targetElement.bounds && it.text == targetElement.text
        }

        if (matchedIndex >= 0) {
            stop()
            startReading(elements, matchedIndex)
        } else {
            // Try approximate match by Y position
            val approximateIndex = elements.indexOfFirst {
                it.centerY >= targetElement.centerY
            }
            stop()
            startReading(elements, approximateIndex.coerceAtLeast(0))
        }
    }

    fun getReadingState(): ReadingState = readingState

    fun isSpeaking(): Boolean = tts?.isSpeaking ?: false

    fun destroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
