package com.smartreader.app.ui

import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.materialswitch.MaterialSwitch
import com.smartreader.app.R
import com.smartreader.app.tts.TTSController
import com.smartreader.app.utils.PreferenceManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var preferenceManager: PreferenceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        preferenceManager = (application as com.smartreader.app.SmartReaderApplication).preferenceManager

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setupSpeedControl()
        setupPitchControl()
        setupLanguageControl()
        setupThemeControl()
        setupVoiceFeedbackToggle()
    }

    private fun setupSpeedControl() {
        val speedSeekBar = findViewById<SeekBar>(R.id.seekbar_speed)
        val speedValue = findViewById<TextView>(R.id.speed_value)

        speedSeekBar.max = 200 // 0.1x to 3.0x mapped to 10-300
        speedSeekBar.progress = ((preferenceManager.speechRate * 100) - 10).toInt().coerceIn(0, 200)

        updateSpeedLabel(speedSeekBar.progress, speedValue)

        speedSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val rate = (progress + 10) / 100f
                updateSpeedLabel(progress, speedValue)
                if (fromUser) {
                    preferenceManager.speechRate = rate
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    private fun updateSpeedLabel(progress: Int, textView: TextView) {
        val rate = (progress + 10) / 100f
        textView.text = String.format("%.1fx", rate)
    }

    private fun setupPitchControl() {
        val pitchSeekBar = findViewById<SeekBar>(R.id.seekbar_pitch)
        val pitchValue = findViewById<TextView>(R.id.pitch_value)

        pitchSeekBar.max = 200 // 0.5x to 3.0x mapped to 50-300
        pitchSeekBar.progress = ((preferenceManager.pitch * 100) - 50).toInt().coerceIn(0, 200)

        updatePitchLabel(pitchSeekBar.progress, pitchValue)

        pitchSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val pitch = (progress + 50) / 100f
                updatePitchLabel(progress, pitchValue)
                if (fromUser) {
                    preferenceManager.pitch = pitch
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    private fun updatePitchLabel(progress: Int, textView: TextView) {
        val pitch = (progress + 50) / 100f
        textView.text = String.format("%.1f", pitch)
    }

    private fun setupLanguageControl() {
        val languageSpinner = findViewById<android.widget.Spinner>(R.id.spinner_language)
        val ttsController = TTSController(this)
        val availableLanguages = ttsController.getAvailableLanguages()
        val displayNames = availableLanguages.map { ttsController.getLanguageDisplayName(it) }
        val currentLang = preferenceManager.language

        val adapter = android.widget.ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            displayNames
        )
        languageSpinner.adapter = adapter

        val currentIndex = availableLanguages.indexOf(currentLang)
        if (currentIndex >= 0) {
            languageSpinner.setSelection(currentIndex)
        }

        languageSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: android.widget.AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                val selectedLang = availableLanguages[position]
                preferenceManager.language = selectedLang
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        ttsController.destroy()
    }

    private fun setupThemeControl() {
        val darkModeSwitch = findViewById<MaterialSwitch>(R.id.switch_dark_mode)
        darkModeSwitch.isChecked = preferenceManager.isDarkMode

        darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            preferenceManager.isDarkMode = isChecked
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
    }

    private fun setupVoiceFeedbackToggle() {
        val voiceFeedbackSwitch = findViewById<MaterialSwitch>(R.id.switch_voice_feedback)
        voiceFeedbackSwitch.isChecked = preferenceManager.voiceFeedback

        voiceFeedbackSwitch.setOnCheckedChangeListener { _, isChecked ->
            preferenceManager.voiceFeedback = isChecked
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
