package com.smartreader.app.service

import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.lifecycleScope
import com.smartreader.app.R
import com.smartreader.app.tts.TTSController
import com.smartreader.app.ui.SettingsActivity
import com.smartreader.app.utils.*
import kotlinx.coroutines.*
import kotlin.math.abs

/**
 * Foreground service that manages the floating button overlay and coordinates
 * reading flow between AccessibilityService and TTS controller.
 */
class FloatingOverlayService : Service(), LifecycleOwner {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingButtonView: View
    private lateinit var quickMenuView: View
    private lateinit var progressBarView: View
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var ttsController: TTSController

    private var layoutParams: WindowManager.LayoutParams? = null
    private var menuLayoutParams: WindowManager.LayoutParams? = null
    private var progressLayoutParams: WindowManager.LayoutParams? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var lastClickTime = 0L
    private val DOUBLE_CLICK_THRESHOLD = 400L
    private val LONG_PRESS_THRESHOLD = 500L
    private var longPressHandler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null
    private var isDragging = false
    private var isQuickMenuVisible = false

    private var currentTextElements: List<ScreenTextElement> = emptyList()
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Lifecycle
    private val lifecycleRegistry = LifecycleRegistry(this)

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    companion object {
        const val CHANNEL_ID = "smart_reader_overlay_channel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        lifecycleRegistry.currentState = Lifecycle.State.CREATED

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        preferenceManager = (application as com.smartreader.app.SmartReaderApplication).preferenceManager

        ttsController = TTSController(this)
        ttsController.initialize(preferenceManager)

        setupTTSListeners()
        setupAccessibilityListener()

        createNotificationChannel()
        inflateViews()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        startForeground(NOTIFICATION_ID, buildNotification())
        showFloatingButton()

        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        return START_STICKY
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  TTS Listeners
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private fun setupTTSListeners() {
        ttsController.onReadingProgress = { index, total ->
            updateProgressBar(index, total)
        }

        ttsController.onReadingComplete = {
            updateFloatingButtonState(FloatingButtonState.IDLE)
            hideProgressBar()
            if (preferenceManager.voiceFeedback) {
                // State reset is enough
            }
        }

        ttsController.onElementStarted = { element ->
            highlightReadingElement(element)
        }

        ttsController.onError = { message ->
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupAccessibilityListener() {
        ScreenReaderAccessibilityService.onTextElementsDetected = { elements ->
            currentTextElements = elements
        }

        ScreenReaderAccessibilityService.onUserTappedElement = { element ->
            ttsController.jumpToElement(currentTextElements, element)
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  View Inflation & Setup
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private fun inflateViews() {
        inflateFloatingButton()
        inflateQuickMenu()
        inflateProgressBar()
    }

    private fun inflateFloatingButton() {
        floatingButtonView = LayoutInflater.from(this).inflate(R.layout.floating_button, null)

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        layoutParams?.gravity = Gravity.TOP or Gravity.START

        // Restore saved position or set default
        val savedX = preferenceManager.floatingButtonX
        val savedY = preferenceManager.floatingButtonY
        if (savedX >= 0 && savedY >= 0) {
            layoutParams?.x = savedX
            layoutParams?.y = savedY
        } else {
            val displaySize = Point()
            windowManager.defaultDisplay.getSize(displaySize)
            layoutParams?.x = displaySize.x - 200
            layoutParams?.y = displaySize.y / 3
        }

        setupFloatingButtonTouchListener()
        updateFloatingButtonIcon()
    }

    private fun setupFloatingButtonTouchListener() {
        val fabContainer = floatingButtonView.findViewById<FrameLayout>(R.id.fab_container)
        val fabIcon = floatingButtonView.findViewById<ImageView>(R.id.fab_icon)

        fabContainer.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams?.x ?: 0
                    initialY = layoutParams?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false

                    // Start long press detection
                    longPressRunnable = Runnable {
                        if (!isDragging) {
                            showQuickMenu()
                            performHapticFeedback()
                        }
                    }
                    longPressHandler.postDelayed(longPressRunnable!!, LONG_PRESS_THRESHOLD)

                    return@setOnTouchListener true
                }

                MotionEvent.ACTION_MOVE -> {
                    val deltaX = event.rawX - initialTouchX
                    val deltaY = event.rawY - initialTouchY

                    if (abs(deltaX) > 5 || abs(deltaY) > 5) {
                        isDragging = true
                        longPressHandler.removeCallbacks(longPressRunnable ?: return@setOnTouchListener true)

                        layoutParams?.x = (initialX + deltaX).toInt()
                        layoutParams?.y = (initialY + deltaY).toInt()

                        // Constrain to screen bounds
                        clampPosition()

                        windowManager.updateViewLayout(floatingButtonView, layoutParams)
                        hideQuickMenu()
                    }
                    return@setOnTouchListener true
                }

                MotionEvent.ACTION_UP -> {
                    longPressHandler.removeCallbacks(longPressRunnable ?: return@setOnTouchListener true)

                    if (isDragging) {
                        // Save position after drag
                        preferenceManager.floatingButtonX = layoutParams?.x ?: 0
                        preferenceManager.floatingButtonY = layoutParams?.y ?: 0
                    } else {
                        handleTapOrDoubleTap()
                    }
                    return@setOnTouchListener true
                }
            }
            false
        }
    }

    private fun handleTapOrDoubleTap() {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastClickTime < DOUBLE_CLICK_THRESHOLD) {
            // Double tap = Pause/Resume
            handleDoubleTap()
            lastClickTime = 0
        } else {
            // Single tap = deferred to check for double tap
            lastClickTime = currentTime
            Handler(Looper.getMainLooper()).postDelayed({
                if (System.currentTimeMillis() - lastClickTime >= DOUBLE_CLICK_THRESHOLD && lastClickTime > 0) {
                    handleSingleTap()
                    lastClickTime = 0
                }
            }, DOUBLE_CLICK_THRESHOLD)
        }
    }

    private fun handleSingleTap() {
        when (ttsController.getReadingState()) {
            TTSController.ReadingState.IDLE -> {
                startReading()
            }
            TTSController.ReadingState.READING -> {
                // Single tap while reading = nothing (double tap for pause)
                // We could use this as context change
            }
            TTSController.ReadingState.PAUSED -> {
                // Nothing
            }
        }
    }

    private fun handleDoubleTap() {
        when (ttsController.getReadingState()) {
            TTSController.ReadingState.READING -> {
                ttsController.pause()
                updateFloatingButtonState(FloatingButtonState.PAUSED)
            }
            TTSController.ReadingState.PAUSED -> {
                ttsController.resume()
                updateFloatingButtonState(FloatingButtonState.READING)
            }
            TTSController.ReadingState.IDLE -> {
                startReading()
            }
        }
    }

    private fun startReading() {
        if (currentTextElements.isEmpty()) {
            // Try to extract text now
            ScreenReaderAccessibilityService.instance?.let { service ->
                val root = service.rootInActiveWindow
                currentTextElements = service.extractAllVisibleText(root)
                root?.recycle()
            }
        }

        if (currentTextElements.isEmpty()) {
            Toast.makeText(this, R.string.none_text, Toast.LENGTH_SHORT).show()
            return
        }

        ttsController.startReading(currentTextElements)
        updateFloatingButtonState(FloatingButtonState.READING)
        showProgressBar()
    }

    private fun stopReading() {
        ttsController.stop()
        updateFloatingButtonState(FloatingButtonState.IDLE)
        hideProgressBar()
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  Quick Menu
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private fun inflateQuickMenu() {
        quickMenuView = LayoutInflater.from(this).inflate(R.layout.quick_menu, null)

        menuLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        menuLayoutParams?.gravity = Gravity.TOP or Gravity.START

        setupMenuButtons()
    }

    private fun setupMenuButtons() {
        quickMenuView.findViewById<TextView>(R.id.menu_start).setOnClickListener {
            startReading()
            hideQuickMenu()
        }
        quickMenuView.findViewById<TextView>(R.id.menu_pause).setOnClickListener {
            ttsController.pause()
            updateFloatingButtonState(FloatingButtonState.PAUSED)
            hideQuickMenu()
        }
        quickMenuView.findViewById<TextView>(R.id.menu_resume).setOnClickListener {
            ttsController.resume()
            updateFloatingButtonState(FloatingButtonState.READING)
            hideQuickMenu()
        }
        quickMenuView.findViewById<TextView>(R.id.menu_stop).setOnClickListener {
            stopReading()
            hideQuickMenu()
        }
        quickMenuView.findViewById<TextView>(R.id.menu_settings).setOnClickListener {
            openSettings()
            hideQuickMenu()
        }
    }

    private fun showQuickMenu() {
        if (isQuickMenuVisible) return

        // Position menu near the floating button
        val fabX = layoutParams?.x ?: 0
        val fabY = layoutParams?.y ?: 0
        val fabHeight = floatingButtonView.height

        menuLayoutParams?.x = fabX - 100
        menuLayoutParams?.y = fabY + fabHeight + 16

        try {
            windowManager.addView(quickMenuView, menuLayoutParams)
            // Animate in
            quickMenuView.alpha = 0f
            quickMenuView.scaleX = 0.8f
            quickMenuView.scaleY = 0.8f
            quickMenuView.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(200)
                .setInterpolator(OvershootInterpolator())
                .start()

            isQuickMenuVisible = true
            // Auto-hide after 5 seconds
            Handler(Looper.getMainLooper()).postDelayed({
                if (isQuickMenuVisible) hideQuickMenu()
            }, 5000)
        } catch (e: Exception) {
            android.util.Log.e("FloatingOverlay", "Error showing menu", e)
        }
    }

    private fun hideQuickMenu() {
        if (!isQuickMenuVisible) return
        try {
            windowManager.removeView(quickMenuView)
            isQuickMenuVisible = false
        } catch (e: Exception) {
            android.util.Log.e("FloatingOverlay", "Error hiding menu", e)
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  Progress Bar
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private fun inflateProgressBar() {
        progressBarView = LayoutInflater.from(this).inflate(R.layout.reading_progress, null)

        progressLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )

        progressLayoutParams?.gravity = Gravity.TOP
        progressLayoutParams?.y = 0
    }

    private fun showProgressBar() {
        try {
            windowManager.addView(progressBarView, progressLayoutParams)
        } catch (e: Exception) {
            // Already added
        }
    }

    private fun hideProgressBar() {
        try {
            windowManager.removeView(progressBarView)
        } catch (e: Exception) {
            // Not added
        }
    }

    private fun updateProgressBar(current: Int, total: Int) {
        val progressBar = progressBarView.findViewById<ProgressBar>(R.id.reading_progress_bar)
        val progressText = progressBarView.findViewById<TextView>(R.id.progress_text)
        progressBar.max = total
        progressBar.progress = current + 1
        progressText.text = "${current + 1} / $total"
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  Highlight Current Element (visual indicator)
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private fun highlightReadingElement(element: ScreenTextElement) {
        // This is a visual feedback - we update the floating button
        // to show it's actively reading
        updateFloatingButtonState(FloatingButtonState.READING)
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  Floating Button State
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    enum class FloatingButtonState { IDLE, READING, PAUSED }

    private fun updateFloatingButtonState(state: FloatingButtonState) {
        val icon = floatingButtonView.findViewById<ImageView>(R.id.fab_icon)
        val pulseView = floatingButtonView.findViewById<View>(R.id.fab_pulse)
        val stateText = floatingButtonView.findViewById<TextView>(R.id.fab_state_text)

        when (state) {
            FloatingButtonState.IDLE -> {
                icon.setImageResource(R.drawable.ic_play)
                icon.setColorFilter(ContextCompat.getColor(this, R.color.floatingButtonIcon))
                pulseView.visibility = View.GONE
                stateText.text = "▶"
            }
            FloatingButtonState.READING -> {
                icon.setImageResource(R.drawable.ic_reading)
                icon.setColorFilter(ContextCompat.getColor(this, R.color.accent))
                pulseView.visibility = View.VISIBLE
                stateText.text = "●"
                // Start pulse animation
                animatePulse(pulseView)
            }
            FloatingButtonState.PAUSED -> {
                icon.setImageResource(R.drawable.ic_pause)
                icon.setColorFilter(ContextCompat.getColor(this, android.R.color.holo_orange_light))
                pulseView.visibility = View.GONE
                stateText.text = "⏸"
            }
        }
    }

    private fun updateFloatingButtonIcon() {
        val icon = floatingButtonView.findViewById<ImageView>(R.id.fab_icon)
        icon.setImageResource(R.drawable.ic_play)
    }

    private fun animatePulse(view: View) {
        val animator = ValueAnimator.ofFloat(0.6f, 1.0f).apply {
            duration = 800
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { animation ->
                val alpha = animation.animatedValue as Float
                view.alpha = alpha
                view.scaleX = 1f + (1f - alpha) * 0.3f
                view.scaleY = 1f + (1f - alpha) * 0.3f
            }
        }
        animator.start()
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  Utility Methods
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private fun showFloatingButton() {
        try {
            windowManager.addView(floatingButtonView, layoutParams)
        } catch (e: Exception) {
            android.util.Log.e("FloatingOverlay", "Error showing FAB", e)
        }
    }

    private fun clampPosition() {
        val displaySize = Point()
        windowManager.defaultDisplay.getSize(displaySize)

        layoutParams?.let { lp ->
            lp.x = lp.x.coerceIn(0, displaySize.x - floatingButtonView.width)
            lp.y = lp.y.coerceIn(0, displaySize.y - floatingButtonView.height - 100)
        }
    }

    private fun performHapticFeedback() {
        floatingButtonView.performHapticFeedback(
            android.view.HapticFeedbackConstants.LONG_PRESS
        )
    }

    private fun openSettings() {
        val intent = Intent(this, SettingsActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Smart Reader Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notification to keep the floating reader service active"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle(getString(R.string.service_running))
        .setContentText("Tap the floating button to read screen text")
        .setSmallIcon(R.drawable.ic_notification)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setOngoing(true)
        .build()

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    //  Lifecycle
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        serviceScope.cancel()

        try {
            windowManager.removeView(floatingButtonView)
        } catch (e: Exception) {}
        try {
            windowManager.removeView(progressBarView)
        } catch (e: Exception) {}
        try {
            windowManager.removeView(quickMenuView)
        } catch (e: Exception) {}

        ttsController.destroy()
        preferenceManager.isServiceRunning = false
    }
}
